﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AsianFoodRestaurant.Migrations
{
    /// <inheritdoc />
    public partial class AddRequestedRefundAmount : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "RequestedRefundAmount",
                table: "RefundRequests",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RequestedRefundAmount",
                table: "RefundRequests");
        }
    }
}
